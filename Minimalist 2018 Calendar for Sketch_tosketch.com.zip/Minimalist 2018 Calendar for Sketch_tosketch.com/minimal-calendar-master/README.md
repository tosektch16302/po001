# 2018 Minimal Calendar
For sketch, using inter UI font. Available in English and French.

## Preview 
![alt tag](https://github.com/PierreBresson/minimal-calendar/blob/master/preview.png)
