![](https://i.imgur.com/AKqoF4q.png)

# Google Material Icons Library for Sketch - [Download](http://bit.ly/material-icons-library)
This is a Google Material Icons Library for Sketch.
I hope you can fasten up your design process with this as much as I do ✌️.
If you've got any questions, just send me a message on Twitter [🐥 @brandtnewww](http://twitter.com/brandtnewww).

# You're asking what a Sketch Library is?
"A Library is just an ordinary Sketch document that contains Symbols which you can then use in any other Sketch document. If you update any of those Symbols in your Library file, documents containing instances of those Symbols will receive a notification telling you that they can be updated. Here you can preview, check, and confirm changes — and by doing so, you can always ensure your documents are using the up-to-date copies of those components." [sketchapp.com](https://www.sketchapp.com/docs/libraries/)
