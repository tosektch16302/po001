## Superhero Sketch icons
Free superhero Sketch icons for Designers, because we all are superheroes.

## Installing
 - Instuctions by Apple https://support.apple.com/en-us/HT201737

**OR**

 - Locate Sketch in your Applications directory
 - Right click on the icon and select `Get Info`
 - Drag the `.icns` file to the top left corner where the default icon is
 - Alternatively you can just copy (`⌘ + C`) the icon, select the default icon in the top left corner and paste in the new icon (`⌘ + V`)
 - Close and reopen Sketch
 - You should now see the new icon
 - To remove the icon just select the icon from `Get Info` window and hit delete
